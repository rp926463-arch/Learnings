
class TestClass:
    def __init__(self):
        pass
    
    def is_palindrome(self, num):
        if num == str(num)[::-1]: 
            return 'YES'
        else:
            return 'NO'

#t = TestClass()
#print(t.is_palindrome('ana'))